<template>
  <router-view></router-view>
</template>

<script>
// import NavBar from './components/NavBar.vue'

export default {
  name: 'App',
  data() {
    return {
    }
  },
  // components:{NavBar},
  mounted() {
  }
}
</script>
<style>
#app {
  margin: 0;
}
</style>